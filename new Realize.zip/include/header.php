<header>
  <div id="nav-placeholder">

  </div>
  <?include 'nav.php'?>

</header>