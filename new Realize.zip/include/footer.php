<footer>

    <div class="footer">


        <!--    <div class="verticalPadding  logow"></div>-->


        <div class=" container ">

            <div class="row">
                <div class="col-6  col-lg-4">
                    <div class="row">
                        <div class=" col-lg-7  footinfo tcenter ">
                            <p>
                                25 Avenida 1-89 Z.15 VH II
                            </p>
                            <p>
                                Ed Insigne Of. 1113, Guatemala
                            </p>
                        </div>
                        <div class="col-lg-5  footinfo  tcenter">
                            <p>
                                +502 3109-8075

                            </p>
                            <p>
                                <a href="mailto:hello@realizeservice.com" style="color:white;text-decoration: none !important;">
                                    hello@realizeservice.com
                                </a>

                            </p>
                        </div>
                    </div>

                </div>
                <!-- <div class="vline2"></div> -->

                <div class=" col-6  col-lg-7 ">
                    <div class="forceBottom row ">

                        <div class="tcenter  footinfo forceLeftMargin col-lg-3 col-12" onclick="location.href='./porque.php';" style="cursor: pointer;">
                            <p>¿Por qué Realize? </p>
                        </div>
                        <div class="tcenter  footinfo col-lg-2 col-12" style="cursor: pointer;">
                            <p>Portafolio </p>

                        </div>

                        <div class="tcenter footinfo col-lg-2 col-12" onclick="location.href='./herramientas.php';" style="cursor: pointer;">
                            <p>
                                Herramientas
                            </p>
                        </div>
                        <div class="tcenter footinfo col-lg-2 col-12" onclick="location.href='./contacto.php';" style="cursor: pointer;">

                            <p>Contáctenos </p>

                        </div>
                        <div class="tcenter footinfo col-lg-2 col-12" onclick="location.href='./bignotes.php';" style="cursor: pointer;">
                            <p>Big Notes</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</footer>